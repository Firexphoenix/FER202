function About() {
    return (
        <div>
            <h1>About Us</h1>
            <p>
                Welcome to our Quiz App! We aim to provide an engaging platform for users to test their knowledge and stay updated with the latest news. Explore our quizzes, read interesting news, and get in touch with us through the contact page.
            </p>
        </div>
    );
}

export default About;