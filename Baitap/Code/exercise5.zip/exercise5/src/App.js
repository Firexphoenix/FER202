import logo from './logo.svg';
import './App.css';
import Exercise3 from './Exercise3';
import Exercise4 from './Exercise4';
import Exercise5 from './Exercise5';

function App() {
  return (
    // <Exercise3/>
    // <Exercise4/>
    <Exercise5/>
  );
}

export default App;
